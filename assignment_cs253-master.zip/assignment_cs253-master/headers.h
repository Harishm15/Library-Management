#include <bits/stdc++.h>
using namespace std;

class Book;
class Book_database;
class User;
class Professor;
class Student;
class Librarian;
class UserDataBase;